//
//  mMapView.swift
//  nav
//
//  Created by 沈重光 on 2023/6/5.
//

import SwiftUI
import UIKit
import MapKit
import CoreLocation
import Foundation

class mapView: UIViewController,CLLocationManagerDelegate {

    var userLocation:CLLocationManager?
    var data3Arrary: [String] = []
    var dataArrary: [String] = []
    var index:Int = 0


    @IBOutlet weak var mMapView: MKMapView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        let address = "台中市西屯區逢甲大學文華路100號之3"
             geocodeAddress(address: address) { coordinate in
                 if let coordinate = coordinate {
                     print("座標：\(coordinate.latitude), \(coordinate.longitude)")
                 }

             }
           let  addr1 = "台中市西屯區逢甲路20巷6之2號"
            geocodeAddress(address: addr1){ coordinate in
                if let coordinate = coordinate {
                    print("座標：\(coordinate.latitude), \(coordinate.longitude)")
                }

            }
        let  addr2 = "台中市西屯區文華路121之17號"
         geocodeAddress(address: addr2){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
   
         }
   
        let  addr3 = "台中市西屯區文華路121-11號"
         geocodeAddress(address: addr3){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
 
         }
    
        let  addr4 = "台中市西屯區文華路147號"
         geocodeAddress(address: addr4){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr5 = "台中市西屯區福星路232號"
         geocodeAddress(address: addr5){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr6 = "台中市西屯區文華路123號"
         geocodeAddress(address: addr6){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr7 = "台中市西屯區文華路185號"
         geocodeAddress(address: addr7){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        let  addr8 = "台中市西屯區文華路140號"
         geocodeAddress(address: addr8){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        let  addr9 = "台中市西屯區福星路330之6號"
         geocodeAddress(address: addr9){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        let  addr10 = "台中市西屯區文華路127巷15號"
         geocodeAddress(address: addr10){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        
         }
  
    
         func geocodeAddress(address: String, completion: @escaping (CLLocationCoordinate2D?) -> Void) {
             let geocoder = CLGeocoder()
             geocoder.geocodeAddressString(address) { (placemarks, error) in
                 if let error = error {
                     print("Geocoding error: \(error.localizedDescription)")
                     completion(nil)
                     return
                 }
                 
                 guard let placemark = placemarks?.first, let location = placemark.location else {
                     completion(nil)
                     return
                 }
        
                 let coordinate = location.coordinate
                 completion(coordinate)
                 
                 var latitude:CLLocationDegrees = coordinate.latitude
                 var longtitude:CLLocationDegrees =  coordinate.longitude
                 let local:CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: latitude, longitude: longtitude)
                 let xScale:CLLocationDegrees = 0.005
                 let yScale:CLLocationDegrees = 0.005
                 let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
                 let showRegion:MKCoordinateRegion = MKCoordinateRegion.init(center: local, span: Scale)
                 
                 self.mMapView.setRegion(showRegion, animated: false)
                 
                 //釘選
            
                 let point = MKPointAnnotation()
               
                 point.coordinate = local
        
                 self.mMapView.addAnnotation(point)
             }
             
             func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
                 let annotationView = MKMarkerAnnotationView()
                 annotationView.markerTintColor = .purple
                 return annotationView
             }

        let latitude:CLLocationDegrees = 24.1788429
        let longtitude:CLLocationDegrees =  120.6470502
        
        userLocation = CLLocationManager()
        
        userLocation?.requestWhenInUseAuthorization()
        
        userLocation?.delegate = self
        
        userLocation?.desiredAccuracy = kCLLocationAccuracyBest
     
        userLocation?.activityType = .airborne
        
        userLocation?.startUpdatingLocation()
        
        //定義的座標
        let location:CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: latitude, longitude: longtitude)
        let xScale:CLLocationDegrees = 0.005
        let yScale:CLLocationDegrees = 0.005
        let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
        let showRegion:MKCoordinateRegion = MKCoordinateRegion.init(center: location, span: Scale)
        mMapView.setRegion(showRegion, animated: true)
        //釘選
        let point = MKPointAnnotation()
        point.coordinate = location
        mMapView.addAnnotation(point)
        //爪取當下位址
        if let myLocation = userLocation?.location?.coordinate{
            let xScale:CLLocationDegrees = 0.005
            let yScale:CLLocationDegrees = 0.005
            let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
            
            let whereIAm = MKCoordinateRegion(center: myLocation, span: Scale)
            mMapView.setRegion(whereIAm, animated: true)
        }
        mMapView.userTrackingMode = .followWithHeading
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations[0].coordinate)
    }
    override func viewDidDisappear(_ animated: Bool) {
        userLocation?.stopUpdatingLocation()
    }

    
}
