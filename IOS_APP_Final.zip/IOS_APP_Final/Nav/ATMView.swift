//
//  ATMView.swift
//  nav
//
//  Created by 沈重光 on 2023/6/5.
//

import SwiftUI
import UIKit
import MapKit
import CoreLocation
import Foundation
class ATMView: UIViewController ,CLLocationManagerDelegate{

    var userLocation:CLLocationManager?
    var data3Arrary: [String] = []
    var dataArrary: [String] = []
    var index:Int = 0



    @IBOutlet weak var Gym_View: MKMapView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        let address = "台中市西屯區至善路236號"
             geocodeAddress(address: address) { coordinate in
                 if let coordinate = coordinate {
                     print("座標：\(coordinate.latitude), \(coordinate.longitude)")
                 }

             }
           let  addr1 = "台中市西屯區西屯路二段277號"
            geocodeAddress(address: addr1){ coordinate in
                if let coordinate = coordinate {
                    print("座標：\(coordinate.latitude), \(coordinate.longitude)")
                }

            }
        let  addr2 = "台中市西屯區文華路3-3號"
         geocodeAddress(address: addr2){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
   
         }
   
        let  addr3 = "台中市西屯區福星路601號"
         geocodeAddress(address: addr3){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
 
         }
    
        let  addr4 = "台中市西屯區河南路二段268號"
         geocodeAddress(address: addr4){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr5 = "台中市西屯區河南路二段242號"
         geocodeAddress(address: addr5){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr6 = "台中市西屯區文華路100號"
         geocodeAddress(address: addr6){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
  
         }
        let  addr7 = "台中市西屯區西屯路二段268-12號"
         geocodeAddress(address: addr7){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        let  addr8 = "台中市西屯區河南路二段363號"
         geocodeAddress(address: addr8){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
        let  addr9 = "台中市西屯區西屯路二段256巷6號3號樓之1"
         geocodeAddress(address: addr9){ coordinate in
             if let coordinate = coordinate {
                 print("座標：\(coordinate.latitude), \(coordinate.longitude)")
             }
         }
  
        
         }
  
    
         func geocodeAddress(address: String, completion: @escaping (CLLocationCoordinate2D?) -> Void) {
             let geocoder = CLGeocoder()
             geocoder.geocodeAddressString(address) { (placemarks, error) in
                 if let error = error {
                     print("Geocoding error: \(error.localizedDescription)")
                     completion(nil)
                     return
                 }
                 
                 guard let placemark = placemarks?.first, let location = placemark.location else {
                     completion(nil)
                     return
                 }
        
                 let coordinate = location.coordinate
                 completion(coordinate)
                 
                 var latitude:CLLocationDegrees = coordinate.latitude
                 var longtitude:CLLocationDegrees =  coordinate.longitude
                 let local:CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: latitude, longitude: longtitude)
                 let xScale:CLLocationDegrees = 0.01
                 let yScale:CLLocationDegrees = 0.01
                 let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
                 let showRegion:MKCoordinateRegion = MKCoordinateRegion.init(center: local, span: Scale)
                 
                 self.Gym_View.setRegion(showRegion, animated: false)
                 
                 //釘選
            
                 let point = MKPointAnnotation()
               
                 point.coordinate = local
        
                 self.Gym_View.addAnnotation(point)
             }
             
             func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
                 let annotationView = MKMarkerAnnotationView()
                 annotationView.markerTintColor = .purple
                 return annotationView
             }

        let latitude:CLLocationDegrees = 24.1788429
        let longtitude:CLLocationDegrees =  120.6470502
        
        userLocation = CLLocationManager()
        
        userLocation?.requestWhenInUseAuthorization()
        
        userLocation?.delegate = self
        
        userLocation?.desiredAccuracy = kCLLocationAccuracyBest
     
        userLocation?.activityType = .airborne
        
        userLocation?.startUpdatingLocation()
        
        //定義的座標
        let location:CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: latitude, longitude: longtitude)
        let xScale:CLLocationDegrees = 0.01
        let yScale:CLLocationDegrees = 0.01
        let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
        let showRegion:MKCoordinateRegion = MKCoordinateRegion.init(center: location, span: Scale)
             Gym_View.setRegion(showRegion, animated: true)
        //釘選
        let point = MKPointAnnotation()
        point.coordinate = location
             Gym_View.addAnnotation(point)
        //爪取當下位址
        if let myLocation = userLocation?.location?.coordinate{
            let xScale:CLLocationDegrees = 0.001
            let yScale:CLLocationDegrees = 0.001
            let Scale:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
            
            let whereIAm = MKCoordinateRegion(center: myLocation, span: Scale)
            Gym_View.setRegion(whereIAm, animated: true)
        }
             Gym_View.userTrackingMode = .followWithHeading
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations[0].coordinate)
    }
    override func viewDidDisappear(_ animated: Bool) {
        userLocation?.stopUpdatingLocation()
    }

    
}

